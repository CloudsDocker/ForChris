import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class CurrencyCrossGenerator {
    public static void main(String[] args) {
        List<String> ccy = Arrays.asList(new String[]{"AUD","CAD","CNY","CZK","DKK","EUR","GBP","JPY","NOK","NZD","USD"});

       IntStream.range(0,ccy.size()).mapToObj(i->{
            String ccy1= ccy.get(i);
            return IntStream.range(0,ccy.size()).mapToObj(j->{
                String ccy2= ccy.get(j);
                if(ccy1.equals(ccy2)) return String.format(" mapCcyCX.put(\"%s%s\",CCY_CX_SELF);",ccy1,ccy2);
                else if(ccy2.equals("USD"))
                     return String.format(" mapCcyCX.put(\"%s%s\",CCY_CX_DIRECT);",ccy1,ccy2);
                else if(ccy1.equals("USD"))
                    return String.format(" mapCcyCX.put(\"%s%s\",CCY_CX_INVERT);",ccy1,ccy2);
                else
                    return String.format(" mapCcyCX.put(\"%s%s\",CCY_CX_USD);",ccy1,ccy2);
                    }

            ).collect(Collectors.toList());
            }
        ).flatMap(l->l.stream()).forEach(System.out::println);
    }


}
