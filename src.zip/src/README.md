# How to run
- Run ANZCalculatorTest to run unit test
- Run ANZCalculator as a console application to accept data from System input (your keyboard)
## Notes
For actual system, please remove three methods name with prefix `marketData_` with real data feed. 
Here is just a sample with static data.

## Contacts
- Todd Zhang (phray.zhang@gmail.com)