import org.junit.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class ANZCalculatorTest {

    ANZCalculator calculator;
    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        calculator=new ANZCalculator();
    }

    @org.junit.jupiter.api.Test
    void processData_sanity() {
        List<String> list=new ArrayList<>();
        list.add("AUD 100.00 in USD");
        List<String> listOut = Arrays.asList("AUD 100.00 = USD 83.71");
        Assert.assertTrue(calculator.processData(list).containsAll(listOut));
    }

    @org.junit.jupiter.api.Test
    void processData_reverse() {
        List<String> list=new ArrayList<>();
        list.add("USD 100.00 in AUD");
        List<String> listOut = Arrays.asList("USD 100.00 = AUD 119.46");
        Assert.assertTrue(calculator.processData(list).containsAll(listOut));
    }


    @org.junit.jupiter.api.Test
    void processData_self() {
        List<String> list=new ArrayList<>();
        list.add("AUD 100.00 in AUD");
        List<String> listOut = Arrays.asList("AUD 100.00 = AUD 100.00");
        Assert.assertTrue(calculator.processData(list).containsAll(listOut));
    }

    @org.junit.jupiter.api.Test
    void processData_cross() {
        List<String> list=new ArrayList<>();
        list.add("AUD 100.00 in DKK");
        List<String> listOut = Arrays.asList("AUD 100.00 = DKK 505.76");
        List<String> listActual = calculator.processData(list);
        Assert.assertTrue(listActual.containsAll(listOut));
    }

    @org.junit.jupiter.api.Test
    void processData_bad() {
        List<String> list=new ArrayList<>();
        list.add("KRW 1000.00 in FJD");
        List<String> listOut = Arrays.asList("Unable to find rate for KRW/FJD");
        Assert.assertTrue(calculator.processData(list).containsAll(listOut));
    }

    @org.junit.jupiter.api.Test
    void processInput() {
    }
}