public interface CurrencyPair {
    String getBaseCurrency();

    String getCounterCurrency();

     String getSymbol();

    String getSymbol(String post);

    String getSymbolCounter();

    String getSymbolCounter(String prefix);
}