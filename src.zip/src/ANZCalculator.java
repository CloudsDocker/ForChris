
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static java.math.RoundingMode.HALF_UP;

public class ANZCalculator {

    final int SCALE = 6;
    final RoundingMode ROUND_MODE = HALF_UP;
    final String CCY_USD = "USD";
    final String CCY_EUR = "EUR";
    final String CCY_CX_SELF = "SELF";
    final String CCY_CX_DIRECT = "D";
    final String CCY_CX_INVERT = "I";
    final String CCY_CX_USD = "XUSD";
    final String CCY_CX_EUR = "XEUR";

    public static void main(String[] args) {
        ANZCalculator inst = new ANZCalculator();
        List<String> input = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            input.add(scanner.nextLine());
        }
        List<String> listOut = inst.processData(input);
        listOut.stream().forEachOrdered(System.out::println);

    }


    public List<String> processData(List<String> list) {
        return processInput(list).stream().map(o -> calculatePrice(o)).collect(Collectors.toList());
    }

    private String calculatePrice(PriceRequest pr) {
        int precision = marketData_GetDecimalLength(pr.getCcy().getCounterCurrency());
        ;
        BigDecimal result = getActualPrice(pr.getCcy().getBaseCurrency(), pr.getCcy().getCounterCurrency());

        if (result == null) {
            return String.format("Unable to find rate for %s/%s", pr.getCcy().getBaseCurrency(), pr.getCcy().getCounterCurrency());
        }

        result = BigDecimal.valueOf(pr.amount).multiply(result).setScale(SCALE, ROUND_MODE);
        String strOut = formatAmount(result, pr.getCcy().getCounterCurrency());
        String strResult = String.format("%s %s = %s %s", pr.getCcy().getBaseCurrency(), formatAmount(BigDecimal.valueOf(pr.getAmount()), pr.getCcy().getBaseCurrency()), pr.getCcy().getCounterCurrency(), strOut);
        return strResult;
    }

    private BigDecimal getActualPrice(String ccy1, String ccy2) {
        String CCY_CX = null;

        String symbol = ccy1 + ccy2;

        String pricingStrategy = marketData_GetCcyCX().get(ccy1 + ccy2);
        if (pricingStrategy == null) {
            return null;
        }

        switch (pricingStrategy) {
            case CCY_CX_SELF:
                return BigDecimal.ONE;
            case CCY_CX_DIRECT:
                return marketData_GetQuote(symbol);
            case CCY_CX_INVERT:
                String symbolRev = ccy2 + ccy1;
                return BigDecimal.ONE.divide(marketData_GetQuote(symbolRev), SCALE, ROUND_MODE);
            case CCY_CX_USD:
                CCY_CX = CCY_USD;
            case CCY_CX_EUR:
                if (CCY_CX == null)
                    CCY_CX = CCY_EUR;

                // direct cross, e.g. both exist of AUDUSD & USDJPY
                String ccyCx1 = ccy1 + CCY_CX;    // AUDUSD
                String ccyCx2 = CCY_CX + ccy2;    // USDDKK (=> EUR)
                BigDecimal price1 = marketData_GetQuote(ccyCx1);
                BigDecimal price2 = marketData_GetQuote(ccyCx2);
                if (price1 != null && price2 != null) {
                    return price1.multiply(price2);
                } else {
                    // not direct cross, maybe further level cross reference
                    price1 = getActualPrice(ccy1, CCY_CX);
                    price2 = getActualPrice(CCY_CX, ccy2);
                    return price1.multiply(price2);
                }
            default:
                // cross currency
                break;
        }
        return null;
    }

    private String formatAmount(BigDecimal data, String ccy) {
        AmountDecimalFormatter formatter = new AmountDecimalFormatter(marketData_GetDecimalLength(ccy));
        return formatter.format(data);
    }

    public List<PriceRequest> processInput(List<String> inputs) {
        assert inputs != null : "Incorrect price input";
        return inputs.stream().filter(s -> !s.isEmpty()).map(s -> s.toUpperCase()).map(s -> {
            String[] ary = s.split("\\s", 4);
            double amount = Double.valueOf(ary[1]);
            CurrencyPair ccy = new CurrencyPairImpl(ary[0], ary[3]);
            return new PriceRequest(ccy, amount);
        }).collect(Collectors.toList());
    }


    class PriceRequest {
        CurrencyPair ccy;
        double amount;

        public PriceRequest(CurrencyPair ccy, double amount) {
            this.ccy = ccy;
            this.amount = amount;
        }

        public CurrencyPair getCcy() {
            return ccy;
        }

        public void setCcy(CurrencyPair ccy) {
            this.ccy = ccy;
        }

        public double getAmount() {
            return amount;
        }

        public void setAmount(double amount) {
            this.amount = amount;
        }
    }

    enum CurrencyCrossType {
        SAME(1), DIRECT(2), INV(3), CCY(4);

        CurrencyCrossType(int i) {

        }
    }


    private BigDecimal marketData_GetQuote(String ccyPair) {
        Map<String, BigDecimal> prices = new HashMap<>();
        prices.putIfAbsent("AUDUSD", BigDecimal.valueOf(0.8371));
        prices.putIfAbsent("CADUSD", BigDecimal.valueOf(0.8711));
        prices.putIfAbsent("USDCNY", BigDecimal.valueOf(6.1715));
        prices.putIfAbsent("EURUSD", BigDecimal.valueOf(1.2315));
        prices.putIfAbsent("GBPUSD", BigDecimal.valueOf(1.5683));
        prices.putIfAbsent("NZDUSD", BigDecimal.valueOf(0.7750));
        prices.putIfAbsent("USDJPY", BigDecimal.valueOf(119.95));
        prices.putIfAbsent("EURCZK", BigDecimal.valueOf(27.6028));
        prices.putIfAbsent("EURDKK", BigDecimal.valueOf(7.4405));
        prices.putIfAbsent("EURNOK", BigDecimal.valueOf(8.6651));

        return prices.get(ccyPair);
    }

    private int marketData_GetDecimalLength(String ccy) {
        Map<String, Integer> decimalMapping = new HashMap<>();
        decimalMapping.putIfAbsent("AUD", 2);
        decimalMapping.putIfAbsent("CAD", 2);
        decimalMapping.putIfAbsent("CNY", 2);
        decimalMapping.putIfAbsent("CZK", 2);
        decimalMapping.putIfAbsent("DKK", 2);
        decimalMapping.putIfAbsent("EUR", 2);
        decimalMapping.putIfAbsent("GBP", 2);
        decimalMapping.putIfAbsent("USD", 2);
        decimalMapping.putIfAbsent("JPY", 0);
        decimalMapping.putIfAbsent("NOK", 2);
        decimalMapping.putIfAbsent("NZD", 2);
        return decimalMapping.getOrDefault(ccy, 0);
    }

    private Map<String, String> marketData_GetCcyCX() {
        Map<String, String> mapCcyCX = new ConcurrentHashMap<>();
//      following map is auto generated by "CurrencyCrossGenerator"
        mapCcyCX.put("AUDAUD", CCY_CX_SELF);
        mapCcyCX.put("AUDCAD", CCY_CX_USD);
        mapCcyCX.put("AUDCNY", CCY_CX_USD);
        mapCcyCX.put("AUDCZK", CCY_CX_USD);
        mapCcyCX.put("AUDDKK", CCY_CX_USD);
        mapCcyCX.put("AUDEUR", CCY_CX_USD);
        mapCcyCX.put("AUDGBP", CCY_CX_USD);
        mapCcyCX.put("AUDJPY", CCY_CX_USD);
        mapCcyCX.put("AUDNOK", CCY_CX_USD);
        mapCcyCX.put("AUDNZD", CCY_CX_USD);
        mapCcyCX.put("AUDUSD", CCY_CX_DIRECT);
        mapCcyCX.put("CADAUD", CCY_CX_USD);
        mapCcyCX.put("CADCAD", CCY_CX_SELF);
        mapCcyCX.put("CADCNY", CCY_CX_USD);
        mapCcyCX.put("CADCZK", CCY_CX_USD);
        mapCcyCX.put("CADDKK", CCY_CX_USD);
        mapCcyCX.put("CADEUR", CCY_CX_USD);
        mapCcyCX.put("CADGBP", CCY_CX_USD);
        mapCcyCX.put("CADJPY", CCY_CX_USD);
        mapCcyCX.put("CADNOK", CCY_CX_USD);
        mapCcyCX.put("CADNZD", CCY_CX_USD);
        mapCcyCX.put("CADUSD", CCY_CX_DIRECT);
        mapCcyCX.put("CNYAUD", CCY_CX_USD);
        mapCcyCX.put("CNYCAD", CCY_CX_USD);
        mapCcyCX.put("CNYCNY", CCY_CX_SELF);
        mapCcyCX.put("CNYCZK", CCY_CX_USD);
        mapCcyCX.put("CNYDKK", CCY_CX_USD);
        mapCcyCX.put("CNYEUR", CCY_CX_USD);
        mapCcyCX.put("CNYGBP", CCY_CX_USD);
        mapCcyCX.put("CNYJPY", CCY_CX_USD);
        mapCcyCX.put("CNYNOK", CCY_CX_USD);
        mapCcyCX.put("CNYNZD", CCY_CX_USD);
        mapCcyCX.put("CNYUSD", CCY_CX_DIRECT);
        mapCcyCX.put("CZKAUD", CCY_CX_USD);
        mapCcyCX.put("CZKCAD", CCY_CX_USD);
        mapCcyCX.put("CZKCNY", CCY_CX_USD);
        mapCcyCX.put("CZKCZK", CCY_CX_SELF);
        mapCcyCX.put("CZKDKK", CCY_CX_EUR);
        mapCcyCX.put("CZKEUR", CCY_CX_INVERT);
        mapCcyCX.put("CZKGBP", CCY_CX_USD);
        mapCcyCX.put("CZKJPY", CCY_CX_USD);
        mapCcyCX.put("CZKNOK", CCY_CX_EUR);
        mapCcyCX.put("CZKNZD", CCY_CX_USD);
        mapCcyCX.put("CZKUSD", CCY_CX_EUR);
        mapCcyCX.put("DKKAUD", CCY_CX_USD);
        mapCcyCX.put("DKKCAD", CCY_CX_USD);
        mapCcyCX.put("DKKCNY", CCY_CX_USD);
        mapCcyCX.put("DKKCZK", CCY_CX_EUR);
        mapCcyCX.put("DKKDKK", CCY_CX_SELF);
        mapCcyCX.put("DKKEUR", CCY_CX_USD);
        mapCcyCX.put("DKKGBP", CCY_CX_USD);
        mapCcyCX.put("DKKJPY", CCY_CX_USD);
        mapCcyCX.put("DKKNOK", CCY_CX_EUR);
        mapCcyCX.put("DKKNZD", CCY_CX_USD);
        mapCcyCX.put("DKKUSD", CCY_CX_EUR);
        mapCcyCX.put("EURAUD", CCY_CX_USD);
        mapCcyCX.put("EURCAD", CCY_CX_USD);
        mapCcyCX.put("EURCNY", CCY_CX_USD);
        mapCcyCX.put("EURCZK", CCY_CX_DIRECT);
        mapCcyCX.put("EURDKK", CCY_CX_DIRECT);
        mapCcyCX.put("EUREUR", CCY_CX_SELF);
        mapCcyCX.put("EURGBP", CCY_CX_USD);
        mapCcyCX.put("EURJPY", CCY_CX_USD);
        mapCcyCX.put("EURNOK", CCY_CX_DIRECT);
        mapCcyCX.put("EURNZD", CCY_CX_USD);
        mapCcyCX.put("EURUSD", CCY_CX_DIRECT);
        mapCcyCX.put("GBPAUD", CCY_CX_USD);
        mapCcyCX.put("GBPCAD", CCY_CX_USD);
        mapCcyCX.put("GBPCNY", CCY_CX_USD);
        mapCcyCX.put("GBPCZK", CCY_CX_USD);
        mapCcyCX.put("GBPDKK", CCY_CX_USD);
        mapCcyCX.put("GBPEUR", CCY_CX_USD);
        mapCcyCX.put("GBPGBP", CCY_CX_SELF);
        mapCcyCX.put("GBPJPY", CCY_CX_USD);
        mapCcyCX.put("GBPNOK", CCY_CX_USD);
        mapCcyCX.put("GBPNZD", CCY_CX_USD);
        mapCcyCX.put("GBPUSD", CCY_CX_DIRECT);
        mapCcyCX.put("JPYAUD", CCY_CX_USD);
        mapCcyCX.put("JPYCAD", CCY_CX_USD);
        mapCcyCX.put("JPYCNY", CCY_CX_USD);
        mapCcyCX.put("JPYCZK", CCY_CX_USD);
        mapCcyCX.put("JPYDKK", CCY_CX_USD);
        mapCcyCX.put("JPYEUR", CCY_CX_USD);
        mapCcyCX.put("JPYGBP", CCY_CX_USD);
        mapCcyCX.put("JPYJPY", CCY_CX_SELF);
        mapCcyCX.put("JPYNOK", CCY_CX_USD);
        mapCcyCX.put("JPYNZD", CCY_CX_USD);
        mapCcyCX.put("JPYUSD", CCY_CX_DIRECT);
        mapCcyCX.put("NOKAUD", CCY_CX_USD);
        mapCcyCX.put("NOKCAD", CCY_CX_USD);
        mapCcyCX.put("NOKCNY", CCY_CX_USD);
        mapCcyCX.put("NOKCZK", CCY_CX_EUR);
        mapCcyCX.put("NOKDKK", CCY_CX_EUR);
        mapCcyCX.put("NOKEUR", CCY_CX_USD);
        mapCcyCX.put("NOKGBP", CCY_CX_USD);
        mapCcyCX.put("NOKJPY", CCY_CX_USD);
        mapCcyCX.put("NOKNOK", CCY_CX_SELF);
        mapCcyCX.put("NOKNZD", CCY_CX_USD);
        mapCcyCX.put("NOKUSD", CCY_CX_EUR);
        mapCcyCX.put("NZDAUD", CCY_CX_USD);
        mapCcyCX.put("NZDCAD", CCY_CX_USD);
        mapCcyCX.put("NZDCNY", CCY_CX_USD);
        mapCcyCX.put("NZDCZK", CCY_CX_USD);
        mapCcyCX.put("NZDDKK", CCY_CX_USD);
        mapCcyCX.put("NZDEUR", CCY_CX_USD);
        mapCcyCX.put("NZDGBP", CCY_CX_USD);
        mapCcyCX.put("NZDJPY", CCY_CX_USD);
        mapCcyCX.put("NZDNOK", CCY_CX_USD);
        mapCcyCX.put("NZDNZD", CCY_CX_SELF);
        mapCcyCX.put("NZDUSD", CCY_CX_DIRECT);
        mapCcyCX.put("USDAUD", CCY_CX_INVERT);
        mapCcyCX.put("USDCAD", CCY_CX_INVERT);
        mapCcyCX.put("USDCNY", CCY_CX_INVERT);
        mapCcyCX.put("USDCZK", CCY_CX_EUR);
        mapCcyCX.put("USDDKK", CCY_CX_EUR);
        mapCcyCX.put("USDEUR", CCY_CX_INVERT);
        mapCcyCX.put("USDGBP", CCY_CX_INVERT);
        mapCcyCX.put("USDJPY", CCY_CX_DIRECT);
        mapCcyCX.put("USDNOK", CCY_CX_EUR);
        mapCcyCX.put("USDNZD", CCY_CX_INVERT);
        mapCcyCX.put("USDUSD", CCY_CX_SELF);
        return mapCcyCX;

    }


}